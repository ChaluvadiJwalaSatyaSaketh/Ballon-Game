# Ballons Game

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

Create a mobile based video game which asks the players to pop the greatest number of balloons within a time period of 2 minutes. The game must contain the following elements:

1) A timer, which decrements from 02:00 at the beginning of the game to 00:00 at the end of the game.

2) A scorecard, which measures the number of balloons popped during the time duration

3) Arbitrary number of balloons, which randomly appear from the bottom of the screen and flow towards the top of the screen and disappear. Player receives +2 for popping the balloon while it is visible, and a penalty of -1 for every balloon missed.